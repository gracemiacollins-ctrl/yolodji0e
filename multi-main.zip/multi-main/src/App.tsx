import React from 'react'
import EvmSection from './sections/EvmSection'
import SolanaSection from './sections/SolanaSection'
export default function App(){ return (<div className="wrap"><div className="grid"><EvmSection/><SolanaSection/></div></div>) }
